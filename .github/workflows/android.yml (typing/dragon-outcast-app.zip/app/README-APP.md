# Dragon Outcast - aplikacja Android (pionowo, wersja beta)

Opakowanie Capacitor wokół gry hostowanej na https://dragonoutcast.pl.
Aktualizacje gry trafiają do aplikacji od razu, bez nowego APK.

## Jak dostać APK (z telefonu)
1. Wrzuć foldery `app/` i `.github/` do repozytorium gry na GitHubie.
2. GitHub -> Actions -> "Zbuduj APK (Android)" -> Run workflow.
3. Po kilku minutach otwórz zakończone uruchomienie -> Artifacts -> `dragon-outcast-apk` (zip z app-debug.apk).
4. Rozpakuj, zainstaluj na telefonie (zezwól na instalację z nieznanych źródeł).

## Uwagi
- APK jest podpisany kluczem testowym, który zmienia się przy każdej budowie. Nowy APK może wymagać odinstalowania starego. Sama gra aktualizuje się z serwera, więc nowe APK potrzebne tylko przy zmianach aplikacji.
- Zakupy Google Play Billing nie działają w APK spoza sklepu (beta bez płatności).
- Orientacja: tylko pion. iOS odłożony.
- Stan: workflow nieprzetestowany, pierwsza budowa może wymagać poprawek.
